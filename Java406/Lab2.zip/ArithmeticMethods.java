class ArithmeticMethods
{  
    public static void main(String args[]){
      int num1 = 2, num2 = 5, num3 = 8;
      displayNumberPlus10(num1, num2)
      displayNumberPlus100(num2, num1)
      displayNumberPlus1000(num3, num1)
       }
       public static void displayNumberPlus10(int x, int Y)
        num1 = num1 + 10
       {
      }
       public static void displayNumberPlus100(int x, int Y)
        num2 = num1 + 100
       {
       }
       public static void displayNumberPlus1000(int x, int Y)
        num3 = num3 + 1000
       {
        System.out.println("The Number Plus 10 is" + num1 + ",Number Plus 100 is" + num2 +",Number Plus 1000 is" + num3);  
       }  
}  