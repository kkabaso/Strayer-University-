import java.util.Scanner;
class ArithmeticMethods2
{  
    public static void main(String args[]){
      
    Scanner input = new Scanner(System.in);
      System.out.print("Enter the Number >>");
       num1 = input.nextInt();
      System.out.print("Enter Another Number >>");
       num2 = input.nextint();
      System.out.print("Enter Another Number >>");
       num3 = input.nextint();
      computePercentage(num1, num2)
      computePercentage(num2, num1)
      }
     public static void computePercentage(Double x, Double Y)
     {
        System.out.println("The Number Plus 10 is" + num1 + ",Number Plus 100 is" + num2 +",Number Plus 1000 is" + num3);  
       }  
}  
